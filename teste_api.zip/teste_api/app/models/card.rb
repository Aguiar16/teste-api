class Card < ApplicationRecord
belongs_to :list
end
